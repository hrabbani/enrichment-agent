"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const leads_1 = require("../queries/leads");
const client_sqs_1 = require("@aws-sdk/client-sqs");
const dotenv_1 = __importDefault(require("dotenv"));
const path_1 = __importDefault(require("path"));
dotenv_1.default.config({ path: path_1.default.resolve(__dirname, "../.env") });
const router = (0, express_1.Router)();
router.get("/", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const leads = yield (0, leads_1.getAllLeads)();
    res.json(leads);
}));
router.get("/:id", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const lead = yield (0, leads_1.getLeadByID)(req.params.id);
    res.json(lead);
}));
router.post("/:id/enrich", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const enrichment_client = new client_sqs_1.SQSClient({});
    const ENRICHMENT_QUEUE_URL = process.env.enrichment_queue_url;
    console.log("Enrichment queue URL:", ENRICHMENT_QUEUE_URL);
    const enrichment_params = {
        MessageBody: JSON.stringify({
            leadId: req.params.id,
        }),
        QueueUrl: ENRICHMENT_QUEUE_URL,
    };
    try {
        const enrichment_result = yield enrichment_client.send(new client_sqs_1.SendMessageCommand(enrichment_params));
        res.status(201).json(enrichment_result);
        console.log("SQS response:", enrichment_result);
    }
    catch (err) {
        res.status(500).json(enrichment_params);
        console.log("Error sending message", err);
    }
}));
router.post("/", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    console.log(req.body);
    const { name, company } = req.body;
    const newLead = yield (0, leads_1.createLead)(name, company);
    res.status(201).json(newLead);
}));
exports.default = router;
